package com.order.hclorders;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HclordersApplication {

	public static void main(String[] args) {
		SpringApplication.run(HclordersApplication.class, args);
	}

}
