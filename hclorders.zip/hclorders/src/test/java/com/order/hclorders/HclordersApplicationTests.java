package com.order.hclorders;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HclordersApplicationTests {

	@Test
	void contextLoads() {
	}

}
